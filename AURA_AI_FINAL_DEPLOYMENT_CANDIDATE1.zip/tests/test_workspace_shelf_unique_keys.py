"""
Unit tests for workspace asset shelf unique key generation and identical filename handling.
Verifies that multiple PDFs/images with identical filenames in different paths have genuinely
unique element keys and never raise StreamlitDuplicateElementKey.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest

from frontend.app import render_workspace_shelf, init_session_state
from utils.helpers import file_hash


def test_unique_keys_for_same_filename_in_different_folders(tmp_path, monkeypatch):
    """Ensure that two files with the same filename in different directories produce unique keys."""
    # Create mock workspace folder structure
    ws_dir = tmp_path / "workspace"
    ws_dir.mkdir()
    tests_dir = ws_dir / "tests"
    tests_dir.mkdir()

    # Create root PDF and tests PDF with identical filename but different content/paths
    pdf1 = ws_dir / "sample_report.pdf"
    pdf1.write_bytes(b"%PDF-1.4 root version content")

    pdf2 = tests_dir / "sample_report.pdf"
    pdf2.write_bytes(b"%PDF-1.4 tests version content")

    # Generate keys as done in render_workspace_shelf
    key1 = f"load_ws_pdf_{hashlib.sha256(str(pdf1.resolve()).encode('utf-8')).hexdigest()[:12]}"
    key2 = f"load_ws_pdf_{hashlib.sha256(str(pdf2.resolve()).encode('utf-8')).hexdigest()[:12]}"

    assert key1 != key2, "Button keys must be strictly unique for different filesystem paths!"
    assert key1.startswith("load_ws_pdf_")
    assert key2.startswith("load_ws_pdf_")


def test_workspace_shelf_renders_without_duplicate_key_error(monkeypatch):
    """Test that render_workspace_shelf generates no duplicate element keys with real workspace files."""
    captured_keys = set()
    duplicate_keys = set()

    def mock_button(label, key=None, **kwargs):
        if key in captured_keys:
            duplicate_keys.add(key)
        if key:
            captured_keys.add(key)
        return False

    with patch("streamlit.button", side_effect=mock_button), \
         patch("streamlit.markdown"), \
         patch("streamlit.columns", return_value=[MagicMock(), MagicMock()]):
        
        # Initialize session state
        import streamlit as st
        init_session_state()

        render_workspace_shelf()

    assert len(duplicate_keys) == 0, f"Detected duplicate element keys: {duplicate_keys}"
    assert len(captured_keys) > 0, "Expected at least one button key to be registered."


def test_duplicate_pdf_upload_prevention():
    """Verify that attempting to upload the exact same PDF bytes is recognized and does not re-index."""
    import streamlit as st
    init_session_state()

    sample_bytes = b"%PDF-1.4 test duplicate upload bytes"
    h = file_hash(sample_bytes)

    # Simulate document already in uploaded_docs
    st.session_state.uploaded_docs[h] = {
        "id": h,
        "name": "sample.pdf",
        "source": "sample.pdf",
        "pages": 1,
        "size_mb": 0.01,
        "chunks": 2,
        "hash": h[:12],
        "full_hash": h,
        "documents": [],
        "doc_ids": [],
    }

    from frontend.app import handle_pdf_upload
    with patch("streamlit.toast"):
        result = handle_pdf_upload(sample_bytes, "sample.pdf")

    # Should return True and skip duplicate re-indexing
    assert result is True
    assert h in st.session_state.processed_upload_hashes


def test_identical_filename_different_content_coexist():
    """Verify that two distinct PDFs with identical filenames are assigned unique source identifiers."""
    import streamlit as st
    init_session_state()

    pdf_bytes_1 = b"%PDF-1.4 first content"
    h1 = file_hash(pdf_bytes_1)

    st.session_state.uploaded_docs[h1] = {
        "id": h1,
        "name": "report.pdf",
        "source": "report.pdf",
        "pages": 1,
        "size_mb": 0.01,
        "chunks": 2,
        "hash": h1[:12],
        "full_hash": h1,
        "documents": [],
        "doc_ids": [],
    }

    # Second PDF has same filename but different content
    pdf_bytes_2 = b"%PDF-1.4 second content"
    h2 = file_hash(pdf_bytes_2)

    # Check same-name disambiguation logic
    existing_names = [d.get("name") for d in st.session_state.uploaded_docs.values()]
    assert "report.pdf" in existing_names

    stem = Path("report.pdf").stem
    ext = Path("report.pdf").suffix
    sha_hash = h2[:12]
    source_name = f"{stem}_{sha_hash[:6]}{ext}"

    assert source_name != "report.pdf"
    assert source_name.startswith("report_")
    assert source_name.endswith(".pdf")

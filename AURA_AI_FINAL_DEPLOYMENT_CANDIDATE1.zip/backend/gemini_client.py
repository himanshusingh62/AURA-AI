"""
Gemini Client Factory and Error Handler using the modern official google-genai SDK.
Handles client instantiation, explicit API key resolution, credential validation,
and user-friendly error translation.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any

from google import genai
from google.genai import errors

logger = logging.getLogger(__name__)

from config.settings import GEMINI_CHAT_MODEL, get_configured_api_key
from utils.helpers import sanitize_error_message
from utils.usage_tracker import record_api_request
from backend.rate_limit import parse_quota_error


def resolve_api_key(session_key: str | None = None) -> str:
    """Resolve the active Google Gemini API key following secure precedence:
    1. Explicitly passed in session key (from Streamlit session_state).
    2. Streamlit secrets (if running in Streamlit Cloud / local secrets.toml).
    3. Environment variable (from .env or OS environment).

    NOTE: Never mutates os.environ at runtime.
    """
    if session_key and session_key.strip():
        return session_key.strip()

    # Check Streamlit secrets safely without throwing if streamlit is headless or has no secrets
    try:
        import streamlit as st
        if hasattr(st, "secrets") and "GOOGLE_API_KEY" in st.secrets:
            key = st.secrets["GOOGLE_API_KEY"]
            if key and str(key).strip():
                return str(key).strip()
    except Exception:
        pass

    return get_configured_api_key()


def validate_api_key_format(api_key: str) -> tuple[bool, str]:
    """Validate API key format without making network requests.
    Supports both traditional 'AIza...' keys and modern AI Studio 'AQ...' keys.
    """
    if not api_key or not api_key.strip():
        return False, "API key is missing. Please configure your key in .env or settings."

    key = api_key.strip()
    if len(key) < 20:
        return False, "API key is too short to be a valid Google Gemini key."

    if not (key.startswith("AIza") or key.startswith("AQ")):
        return False, "Invalid key format: Google Gemini API keys typically start with 'AIza' or 'AQ'."

    return True, ""


def get_genai_client(api_key: str | None = None) -> genai.Client:
    """Instantiate the official google-genai Client with an explicit API key."""
    resolved_key = resolve_api_key(api_key)
    is_valid, err = validate_api_key_format(resolved_key)
    if not is_valid:
        raise ValueError(f"Authentication error: {err}")

    return genai.Client(api_key=resolved_key)


def verify_api_key_live(api_key: str, model_name: str | None = None) -> tuple[bool, str]:
    """Verify an API key by making a minimal live request to Google Gen AI.

    Returns:
        (is_valid, message)
    """
    is_valid, err = validate_api_key_format(api_key)
    if not is_valid:
        return False, err

    target_model = model_name or GEMINI_CHAT_MODEL
    start_t = time.time()

    try:
        client = genai.Client(api_key=api_key.strip())
        # Make a quick, low-cost count_tokens request to verify auth
        client.models.count_tokens(
            model=target_model,
            contents="ping",
        )
        latency = time.time() - start_t
        record_api_request("verification", "success", latency=latency, model_name=target_model)
        return True, "API Key successfully validated with Google Gen AI."
    except errors.ClientError as exc:
        latency = time.time() - start_t
        quota_info = parse_quota_error(exc, model_name=target_model)
        if quota_info.is_429:
            record_api_request(
                "verification",
                "429_quota_exceeded",
                latency=latency,
                is_429=True,
                error_message=quota_info.friendly_message,
                model_name=target_model,
            )
            return False, quota_info.friendly_message
        record_api_request("verification", "error", latency=latency, error_message=str(exc), model_name=target_model)
        if exc.code == 400 and "API_KEY_INVALID" in str(exc):
            return False, "Google rejected this API key (Invalid API Key)."
        if exc.code == 403:
            return False, "Permission denied for this API key. Ensure Gemini API is enabled in your Google Cloud / AI Studio project."
        return False, f"Google API error: {sanitize_error_message(str(exc))}"
    except Exception as exc:
        latency = time.time() - start_t
        quota_info = parse_quota_error(exc, model_name=target_model)
        if quota_info.is_429:
            record_api_request(
                "verification",
                "429_quota_exceeded",
                latency=latency,
                is_429=True,
                error_message=quota_info.friendly_message,
                model_name=target_model,
            )
            return False, quota_info.friendly_message
        record_api_request("verification", "error", latency=latency, error_message=str(exc), model_name=target_model)
        return False, f"Verification failed: {sanitize_error_message(str(exc))}"


# Known user-facing message prefixes to prevent recursive or double-wrapping
_ALREADY_TRANSLATED_PREFIXES = (
    "Google Gemini daily request quota has been exhausted",
    "Google Gemini temporary rate limit reached",
    "Invalid Google Gemini API key",
    "Authentication failed (HTTP 401)",
    "Access denied (HTTP 403)",
    "Requested model was not found",
    "Google Gemini service is temporarily unavailable",
    "Google internal server error (HTTP 500)",
    "Google Gemini gateway error",
    "Google Gemini gateway timeout",
    "Google Gemini server error",
    "Google Gemini client error",
    "Invalid request parameters (HTTP 400)",
    "Network timeout connecting to Google Gemini API",
    "Network connection error",
    "Application Limit:",
    "Retrieval error:",
    "Vector embedding error:",
)


def translate_genai_error(exc: Exception, model_name: str = "") -> str:
    """Translate technical or Google Gen AI exceptions into clean, user-friendly messages.

    Accurately distinguishes HTTP 400, 401, 403, 404, 429, 500, 502, 503, 504 and network/timeout errors.
    Emits server-side logs with exception type, HTTP status, and sanitized details without leaking secrets.
    """
    raw_str = str(exc)
    sanitized = sanitize_error_message(raw_str)
    exc_type = type(exc).__name__
    status_code = getattr(exc, "code", None) or getattr(exc, "status_code", None)

    # Server-side logging: includes exception type, status code, model, and sanitized detail
    logger.error(
        "Gemini API Exception [%s] (HTTP %s) for model '%s': %s",
        exc_type,
        status_code if status_code is not None else "N/A",
        model_name or "default",
        sanitized,
    )

    # Prevent double-wrapping if exc is already a clean user-facing message
    if any(sanitized.startswith(prefix) for prefix in _ALREADY_TRANSLATED_PREFIXES):
        return sanitized

    # Check for HTTP 429 quota exhaustion or temporary per-minute rate limits
    quota_info = parse_quota_error(exc, model_name=model_name)
    if quota_info.is_429:
        return quota_info.friendly_message

    err_lower = raw_str.lower()
    clean_model = model_name.replace("models/", "") if model_name else "specified model"

    # Specific HTTP status handling (via errors.APIError, errors.ClientError, errors.ServerError, or code attrs)
    if status_code == 400:
        if "api_key_invalid" in err_lower or "api key not valid" in err_lower or "invalid api key" in err_lower:
            return "Invalid Google Gemini API key. Please verify your API key in settings or .env."
        return f"Invalid request parameters (HTTP 400): {sanitized}"

    if status_code == 401:
        return "Authentication failed (HTTP 401): API key is invalid or unauthorized."

    if status_code == 403:
        return "Access denied (HTTP 403): Gemini API service is either disabled, region-restricted, or unauthorized for this API key."

    if status_code == 404:
        return f"Requested model was not found (HTTP 404): Model '{clean_model}' is unavailable or unsupported."

    if status_code == 500:
        return "Google internal server error (HTTP 500): Google Gemini encountered an internal error. Please retry in a few moments."

    if status_code == 502:
        return "Google Gemini gateway error (HTTP 502): Bad gateway response from Google API servers. Please retry in a moment."

    if status_code == 503:
        return "Google Gemini service is temporarily unavailable (HTTP 503): Service is overloaded or undergoing maintenance. Please retry in a few moments."

    if status_code == 504:
        return "Google Gemini gateway timeout (HTTP 504): Upstream Google servers timed out responding. Please retry in a moment."

    if isinstance(exc, errors.ServerError):
        return f"Google Gemini service is temporarily unavailable (HTTP {status_code or 503}): {sanitized}. Please retry in a few moments."

    if isinstance(exc, errors.ClientError):
        return f"Google Gemini client error (HTTP {status_code or 400}): {sanitized}"

    # Network timeout distinction
    if (
        isinstance(exc, TimeoutError)
        or "timeout" in err_lower
        or "timed out" in err_lower
        or "timeouterror" in err_lower
    ):
        return "Network timeout connecting to Google Gemini API. Please check your internet connection."

    # Network connection failure distinction
    if (
        isinstance(exc, ConnectionError)
        or "connecterror" in err_lower
        or "connection" in err_lower
        or "nameresolutionerror" in err_lower
        or "getaddrinfo failed" in err_lower
        or "network unreachable" in err_lower
        or "failed to establish a new connection" in err_lower
        or "connection refused" in err_lower
    ):
        return "Network connection error: Failed to reach Google Gemini API servers. Please verify internet connectivity and firewall rules."

    return f"AI processing error: {sanitized}"
